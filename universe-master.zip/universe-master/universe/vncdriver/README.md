# Python VNC driver implementation

This Python VNC driver is using an older API, and needs a small amount
of work to once again become a good backend. We haven't bothered with
this since the Go driver is much faster. We would take a pull request
to fix it though!
